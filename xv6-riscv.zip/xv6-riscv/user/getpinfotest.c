#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"
#include "kernel/pstat.h"
#include "kernel/random.h"


int main(int argc, char **argv) {
    // Create a structure to hold the process information
    struct pstat pinfo;
    // Call your getpinfo function and pass the pinfo structure
    int result = getpinfo(&pinfo);

    if (result == 0) {
        // Print the process information
        for (int p = 0; p < NPROC; p++) {
            if (pinfo.inuse[p]) {
                printf("Process ID: %d, Tickets: %d, PID: %d, Ticks: %d\n",
                       p, pinfo.tickets[p], pinfo.pid[p], pinfo.ticks[p]);
            }
        }
    } else {
        printf("Error: getpinfo failed with result %d\n", result);
    }

    return 0;
}




