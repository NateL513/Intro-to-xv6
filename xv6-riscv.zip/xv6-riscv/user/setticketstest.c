#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

// Include function's definition
int settickets(int number);

int main(int argc, char **argv) {
    int pid = getpid();

    printf("Process ID: %d\n", pid);
    
    // Call your settickets function with different inputs and print the results
    int result1 = settickets(5);
    printf("Setting 5 tickets: Result = %d\n", result1);
    
    int result2 = settickets(-3);
    printf("Setting -3 tickets: Result = %d\n", result2);

    int result3 = settickets(0);
    printf("Setting 0 tickets: Result = %d\n", result3);

    int result4 = settickets(1);
    printf("Setting 1 ticket: Result = %d\n", result4);
    
    // You can add more test cases here if needed
    
    return 0;
}
